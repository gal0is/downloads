<?php /* Smarty version 2.6.18, created on 2008-10-07 04:36:18
         compiled from thirdMenu.tpl */ ?>
<html>
<head>
<script type="text/javascript" src="include/scripts/prototype.js?code=<?php echo $this->_tpl_vars['random']; ?>
"></script>
<script type="text/javascript" src="include/scripts/prototype-ext.js?code=<?php echo $this->_tpl_vars['random']; ?>
"></script>
<link rel="stylesheet" href="include/css/default.css?code=<?php echo $this->_tpl_vars['random']; ?>
" type="text/css">
<link rel="stylesheet" href="include/css/style.css?code=<?php echo $this->_tpl_vars['random']; ?>
" type="text/css">
<link rel="stylesheet" href="include/css/fonts.css?code=<?php echo $this->_tpl_vars['random']; ?>
" type="text/css">
<link rel="stylesheet" href="include/css/layout.css?code=<?php echo $this->_tpl_vars['random']; ?>
" type="text/css">
</head>
<body onload="<?php if ($this->_tpl_vars['sessionEnabled'] == true): ?>loadThirdMenu()<?php endif; ?>">
<table class="tableStyle" height="100%">
	<tr>
		<td class="leftEdge" width="11px" height="100%"><img src="images/clear.gif" width="11"><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /></td>
		<td valign="top">	
			<table class="tableStyle" height="100%" width="100%">
				<tr>
					<td class="leftInside" style="width: 8px;"><img src="images/clear.gif" width="8"/></td>
					<td class="padding2Top topAlign">
						<table border="0" cellspacing="0" cellpadding="0" class="1" id="Tree" width="144">
			            	<tr>
								<td class="thardNavContainerTopLeftImg"><img src="images/clear.gif" width="5" height="5"/></td>
								<td class="thardNavContainerTopMiddleImg spacer100Percent"><img src="images/clear.gif" width="5"/></td>
								<td class="thardNavContainerTopRightImg"><img src="images/clear.gif" width="5"/></td>
				            </tr>
							<tr>
								<td class="thardNavContainerSecondTopLeftImg"><img src="images/clear.gif" width="5"/></td>
								<td class="leftNavBg padding1Top topAlign" id="TreeFrame">
                                    <?php if ($this->_tpl_vars['sessionEnabled'] == true): ?>
						                                               <?php endif; ?>
									</td>
								<td class="thardNavContainerSecondTopRightImg"><img src="images/clear.gif" width="5"/></td>
							</tr>
							<tr>
								<td class="thardNavContainerBottomLeftImg"><img src="images/clear.gif" width="5" height="5"/></td>
								<td class="thardNavContainerBottomMiddleImg"><img src="images/clear.gif" height="5"/></td>
								<td class="thardNavContainerBottomRightImg"><img src="images/clear.gif" width="5"/></td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
</body>
</html>